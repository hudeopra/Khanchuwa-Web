import React from "react";

export default function NotFound() {
  return (
    <main className="p-3 max-w-4xl mx-auto text-center">
      <h1>404 error page not found</h1>
    </main>
  );
}
