import React from "react";

const TestingComponent = () => {
  return <div>TestingComponent</div>;
};

export default TestingComponent;
